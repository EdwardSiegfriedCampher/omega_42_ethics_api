
from ethics_engine import compute_phiT_score, compute_sun_index, ethic_check

def run_demo():
    print("\n🌌 Omega 42 Ethics Engine Demo")
    print("Choose an option:")
    print("1. Evaluate φT Score")
    print("2. Run SUN Index")
    print("3. Full Ethic Check")
    print("0. Exit")

    while True:
        choice = input("\nEnter your choice: ")
        if choice == "0":
            print("Exiting demo.")
            break
        elif choice in ["1", "2", "3"]:
            user_input = input("Enter situation description: ")
            data = {"query": user_input} if choice != "3" else {
                "observer_id": "demo_user",
                "situation": {
                    "description": user_input,
                    "affected_groups": ["public", "government", "environment"]
                }
            }

            if choice == "1":
                result = compute_phiT_score(data)
            elif choice == "2":
                result = compute_sun_index(data)
            elif choice == "3":
                result = ethic_check(data)

            print("\nResult:")
            for k, v in result.items():
                print(f"  {k}: {v}")
        else:
            print("Invalid choice. Please select 0, 1, 2, or 3.")

if __name__ == "__main__":
    run_demo()
