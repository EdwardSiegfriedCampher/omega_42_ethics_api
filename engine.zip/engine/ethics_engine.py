
import math
import hashlib
import json
import random

phi = (1 + math.sqrt(5)) / 2
dr24_cycle = [1, 1, 2, 3, 5, 8, 4, 3, 7, 1, 8, 9, 8, 8, 7, 6, 4, 1, 5, 6, 2, 8, 1, 9]

def digital_root(n):
    return n if n < 10 else digital_root(sum(map(int, str(n))))

def compute_phiT_score(text_input):
    if isinstance(text_input, dict):
        text_input = json.dumps(text_input)
    h = hashlib.sha256(text_input.encode()).hexdigest()
    num = int(h[:16], 16)
    dr_sum = digital_root(num)

    position = dr_sum % 24
    cycle_value = dr24_cycle[position]
    normalized = cycle_value / 9
    phi_adjusted = abs((phi - 1) - (normalized - 0.5))

    score = round(1.0 - phi_adjusted, 3)
    label = (
        "Low Coherence" if score < 0.6 else
        "Moderate Coherence" if score < 0.85 else
        "High Coherence"
    )
    resonance = (
        "ϕ-divergent" if score < 0.6 else
        "ϕ-approaching" if score < 0.85 else
        "ϕ-harmonic"
    )
    drift = abs(position - 12)

    return {
        "phiT_score": score,
        "score_label": label,
        "cycle_drift": drift,
        "resonance_zone": resonance,
        "advisory": "Adjust action for lower-harmonic stakeholder groups." if score < 0.85 else "Action within harmonic resonance."
    }

def compute_sun_index(text_input, max_paths=13):
    if isinstance(text_input, dict):
        text_input = json.dumps(text_input)

    h = hashlib.sha256(text_input.encode()).hexdigest()
    entropy_seed = int(h[:8], 16)
    random.seed(entropy_seed)

    divergent_paths = random.randint(3, max_paths)
    sun_index = round(1 / (divergent_paths ** 0.5), 3)

    uncertainty_level = (
        "High" if sun_index > 0.6 else
        "Moderate" if sun_index > 0.3 else
        "Low"
    )

    dominant_branch = random.choice([
        "ϕ-prioritized utility",
        "Observer safety weighting",
        "Systemic coherence enforcement",
        "Stakeholder equality maximization",
        "ϕ-harmonic mean ethics",
        "Memory-preserving resonance"
    ])

    return {
        "sun_index": sun_index,
        "uncertainty_level": uncertainty_level,
        "divergent_paths_considered": divergent_paths,
        "dominant_phi_branch": dominant_branch,
        "note": "Lower sun_index indicates stronger AI humility."
    }

def ethic_check(situation):
    if isinstance(situation, dict):
        situation_text = json.dumps(situation)
    else:
        situation_text = str(situation)

    h = hashlib.sha256(situation_text.encode()).hexdigest()
    entropy_seed = int(h[:8], 16)
    random.seed(entropy_seed)

    phiT = compute_phiT_score(situation_text)
    sun = compute_sun_index(situation_text)

    all_nodes = [
        "Node-E6.13: Resource fairness",
        "Node-E6.21: Vital need prioritization",
        "Node-E6.34: Stakeholder memory resonance",
        "Node-E6.08: Long-term harmonic outcome",
        "Node-E6.17: Observer sovereignty respect",
        "Node-E6.29: ϕ-field stabilization",
        "Node-E6.05: Recursive intent validation"
    ]
    path_len = random.randint(3, 5)
    ethical_path = random.sample(all_nodes, path_len)

    possible_biases = ["eco-prioritization", "human-centrism", "outcome bias", "short-termism"]
    bias_detected = random.sample(possible_biases, random.randint(0, 2))

    trace_url = f"/spiral-trace/{h[:12]}"

    recommendation = "Proceed with adjustment. Notify all affected parties of harmonic offset plan." if phiT["phiT_score"] > 0.7 else "Action requires re-evaluation and ethical tuning."

    return {
        "phiT_score": phiT["phiT_score"],
        "ethical_path": ethical_path,
        "bias_detected": bias_detected,
        "spiral_trace_url": trace_url,
        "recommendation": recommendation
    }
